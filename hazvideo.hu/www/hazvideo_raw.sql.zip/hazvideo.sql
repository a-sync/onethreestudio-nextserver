-- phpMyAdmin SQL Dump
-- version 2.10.0.2
-- http://www.phpmyadmin.net
-- 
-- Hoszt: localhost
-- Létrehozás ideje: 2009. Ápr 30. 15:25
-- Szerver verzió: 5.0.27
-- PHP Verzió: 4.3.11RC1-dev

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Adatbázis: `hazvideo`
-- 

-- --------------------------------------------------------

-- 
-- Tábla szerkezet: `esemenyek`
-- 

CREATE TABLE `esemenyek` (
  `esid` int(10) unsigned NOT NULL auto_increment,
  `hiid` int(10) unsigned NOT NULL default '0',
  `text` text collate utf8_unicode_ci NOT NULL,
  `statusz` tinyint(1) unsigned NOT NULL default '0',
  `prioritas` tinyint(1) unsigned NOT NULL default '0',
  `datum` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`esid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=97 ;

-- 
-- Tábla adatok: `esemenyek`
-- 

INSERT INTO `esemenyek` (`esid`, `hiid`, `text`, `statusz`, `prioritas`, `datum`) VALUES 
(1, 0, 'Imperdiet leo. In consequat rhoncus n', 0, 2, 1172839353),
(2, 35, 'At. Praesent', 0, 1, 1170180305),
(3, 16, 'Ris viverra', 0, 3, 1158380956),
(4, 36, 'Dolor sit am', 0, 3, 1100070584),
(5, 0, 'A vel, euismod ac, sodales quis, arcu. Fusce ut tortor. Cras placerat augue id augue. Suspendisse f', 0, 2, 1212225858),
(6, 85, 'Is ali', 0, 1, 1036488613),
(7, 54, ', risus. Nunc eu sapien nec lig', 0, 2, 1217344105),
(8, 84, 'Is turpis convallis', 0, 1, 1098486303),
(9, 73, 'Pretium id, volutpat s', 0, 2, 1216555827),
(10, 50, 'Sit amet, sus', 0, 0, 1055692762),
(11, 0, '. Donec vitae nulla id felis vehicula ultrices. Donec ipsum. Aenean lobortis lorem eget odio. Nunc rutrum. Suspendisse a', 0, 3, 1035146742),
(12, 45, 'Nec ligula ornare fring', 0, 3, 1024979192),
(13, 76, 'Disse magna nibh, viverra vel, euismod ac, sodales quis, arcu. Fusce ut tortor. Cras placerat augue id augue. Suspendisse facilisis aliquam', 0, 2, 1035996417),
(14, 66, 'Hendrerit sapien', 0, 1, 998348344),
(15, 35, 'Cenas eget', 0, 3, 1112910492),
(16, 55, 'Onsectetur adipiscing elit. M', 0, 2, 1156209426),
(17, 0, 'It amet, magna. Donec', 0, 1, 1106237245),
(18, 59, 'Met elemen', 0, 1, 1042389899),
(19, 96, 'O, tristique et, ultrices sagittis, malesuada id, neque. Sed sed n', 0, 3, 1138255487),
(20, 0, 'Ta id, malesuada a, leo. Nunc in massa eget massa eleifend viverra. Donec porta aliquam turpis. Vestibulum ante ipsum', 0, 3, 990631356),
(21, 83, 'Isse a diam vitae mauri', 0, 3, 1223470062),
(22, 54, 'Ut tort', 0, 2, 1149331984),
(23, 0, 'Ut tortor. Mauris viv', 0, 1, 1095250382),
(24, 21, 'Dimentum egestas. Pellentesque porttitor justo et urna.', 0, 2, 1064413375),
(25, 68, 'E porttitor, diam. Pellentesque', 0, 2, 1074692970),
(26, 37, 'Aliquam urna dolor, consectetur', 0, 3, 1070115162),
(27, 1, 'Isis. Lorem ipsum dolor', 0, 3, 1045784303),
(28, 73, 'Nean faucibus tellus et mi.', 0, 2, 1138868040),
(29, 97, 'Volutpat sit amet, magna. Donec sem', 0, 1, 1060100522),
(30, 0, 'Lectus bibendum feugiat. Vivamus dolor leo, auctor quis, pretium id, volutpat sit amet, magna. Donec sem. Quisque ac nisi. Donec a nunc vitae eros ornare congue. In a', 0, 0, 1127260356),
(31, 72, 'Unc scelerisque', 0, 0, 1195121940),
(32, 2, 'Nc quam, ultricies at, elementum nec, aliquet eget, quam', 0, 1, 1075006485),
(33, 0, 'E mauris aliquet laoreet. Maecenas hen', 0, 2, 1063422885),
(34, 38, 'Tincid', 0, 3, 1235561326),
(35, 25, 'Bibendum feugiat. Vivamu', 0, 3, 1185501070),
(36, 0, 'T. Vivamus dolor leo, auc', 0, 0, 1220472642),
(37, 0, 'Uscipit non, lorem. Etiam vive', 0, 2, 1049071247),
(38, 41, 'Netus et malesuada fames ac turpis eges', 0, 0, 1005812965),
(39, 20, 'Na. Morbi non tortor. Nulla sollicitu', 0, 1, 1093513225),
(40, 23, 'Elit. Mauris mau', 0, 1, 1174520572),
(41, 10, 'KiemeltsÃ©g beÃ¡llÃ­tÃ¡sÃ¡t / meghosszabbÃ­tÃ¡sÃ¡t kÃ©rem.', 0, 3, 1239797806),
(42, 10, 'KiemeltsÃ©g beÃ¡llÃ­tÃ¡sÃ¡t / meghosszabbÃ­tÃ¡sÃ¡t kÃ©rem.', 0, 3, 1239797832),
(43, 10, 'Ã‰rvÃ©nyessÃ©g beÃ¡llÃ­tÃ¡sÃ¡t / meghosszabbÃ­tÃ¡sÃ¡t kÃ©rem.', 1, 3, 1239797844),
(44, 10, 'KijelentkezÃ©s.', 0, 0, 1239798084),
(45, 10, 'BejelentkezÃ©s.', 0, 0, 1239805218),
(46, 10, 'Ã‰rvÃ©nyessÃ©g beÃ¡llÃ­tÃ¡sÃ¡t / meghosszabbÃ­tÃ¡sÃ¡t kÃ©rem.', 0, 3, 1239805256),
(47, 10, 'KiemeltsÃ©g beÃ¡llÃ­tÃ¡sÃ¡t / meghosszabbÃ­tÃ¡sÃ¡t kÃ©rem.', 0, 3, 1239805316),
(48, 10, 'Sikertelen bejelentkezÃ©si kÃ­sÃ©rlet. (IP: 127.0.0.1)', 0, 0, 1240076494),
(49, 10, 'BejelentkezÃ©s.', 0, 0, 1240076529),
(50, 10, 'KijelentkezÃ©s.', 0, 0, 1240077912),
(51, 10, 'Sikertelen bejelentkezÃ©si kÃ­sÃ©rlet. (IP: 127.0.0.1)', 0, 0, 1240077925),
(52, 10, 'BejelentkezÃ©s.', 0, 0, 1240077938),
(53, 10, 'KijelentkezÃ©s.', 0, 0, 1240078025),
(54, 9, 'BejelentkezÃ©s.', 0, 0, 1240078176),
(55, 9, 'KijelentkezÃ©s.', 0, 0, 1240085342),
(56, 10, 'BejelentkezÃ©s.', 0, 0, 1240088809),
(57, 10, 'Ã‰rvÃ©nyessÃ©g meghosszabbÃ­tÃ¡sÃ¡t kÃ©rem!', 0, 3, 1240091689),
(58, 10, 'KiemeltsÃ©g meghosszabbÃ­tÃ¡sÃ¡t kÃ©rem!', 1, 3, 1240091715),
(59, 10, 'KijelentkezÃ©s.', 0, 0, 1240092659),
(60, 10, 'BejelentkezÃ©s.', 0, 0, 1240092806),
(61, 10, 'KijelentkezÃ©s.', 0, 0, 1240092840),
(62, 10, 'BejelentkezÃ©s.', 0, 0, 1240093005),
(63, 10, 'KijelentkezÃ©s.', 0, 0, 1240093890),
(64, 10, 'BejelentkezÃ©s.', 0, 0, 1240094392),
(65, 10, 'KijelentkezÃ©s.', 0, 0, 1240094433),
(66, 10, 'BejelentkezÃ©s.', 0, 0, 1240094442),
(67, 9, 'BejelentkezÃ©s.', 0, 0, 1240094527),
(68, 8, 'Sikertelen bejelentkezÃ©si kÃ­sÃ©rlet. (IP: 127.0.0.1)', 1, 0, 1240094539),
(69, 8, 'BejelentkezÃ©s.', 0, 0, 1240094545),
(70, 8, 'KijelentkezÃ©s.', 0, 0, 1240094558),
(71, 8, 'BejelentkezÃ©s.', 0, 0, 1240094866),
(72, 9, 'BejelentkezÃ©s.', 0, 0, 1240094879),
(73, 9, 'KijelentkezÃ©s.', 0, 0, 1240095385),
(74, 10, 'BejelentkezÃ©s.', 0, 0, 1240095392),
(75, 10, 'KijelentkezÃ©s.', 0, 0, 1240095410),
(76, 10, 'BejelentkezÃ©s.', 0, 0, 1240095483),
(77, 10, 'KiemeltsÃ©g meghosszabbÃ­tÃ¡sÃ¡t kÃ©rem!', 2, 3, 1240095500),
(78, 10, 'KijelentkezÃ©s.', 0, 0, 1240095513),
(79, 9, 'BejelentkezÃ©s.', 0, 0, 1240095528),
(80, 8, 'Sikertelen bejelentkezÃ©si kÃ­sÃ©rlet. (IP: 127.0.0.1)', 1, 0, 1240095555),
(81, 9, 'KijelentkezÃ©s.', 0, 0, 1240095576),
(82, 9, 'BejelentkezÃ©s.', 0, 0, 1240140266),
(83, 9, 'Ã‰rvÃ©nyessÃ©g meghosszabbÃ­tÃ¡sÃ¡t kÃ©rem! (Jelenleg 2010.01.01-ig Ã©rvÃ©nyes.)', 2, 3, 1240140277),
(84, 9, 'KijelentkezÃ©s.', 0, 0, 1240140283),
(85, 10, 'Sikertelen bejelentkezÃ©si kÃ­sÃ©rlet. (IP: 127.0.0.1)', 1, 0, 1240148120),
(86, 10, 'Sikertelen bejelentkezÃ©si kÃ­sÃ©rlet. (IP: 127.0.0.1)', 1, 0, 1240218102),
(87, 10, 'BejelentkezÃ©s.', 0, 0, 1240218106),
(88, 10, 'KijelentkezÃ©s.', 0, 0, 1240218472),
(89, 10, 'Sikertelen bejelentkezÃ©si kÃ­sÃ©rlet. (IP: 127.0.0.1)', 1, 0, 1240220928),
(90, 10, 'BejelentkezÃ©s.', 0, 0, 1240220932),
(91, 10, 'KijelentkezÃ©s.', 0, 0, 1240221490),
(92, 10, 'Sikertelen bejelentkezÃ©si kÃ­sÃ©rlet. (IP: 127.0.0.1)', 1, 0, 1240221565),
(93, 10, 'BejelentkezÃ©s.', 0, 0, 1240221569),
(94, 10, 'KijelentkezÃ©s.', 0, 0, 1240233467),
(95, 0, 'Admin bejelentkezett. (vector)', 0, 0, 1240233480),
(96, 0, 'Admin bejelentkezett. (vector)', 0, 0, 1240394468);

-- --------------------------------------------------------

-- 
-- Tábla szerkezet: `hirdetesek`
-- 

CREATE TABLE `hirdetesek` (
  `hiid` int(10) unsigned NOT NULL auto_increment,
  `hirdetes_cime` tinytext collate utf8_unicode_ci NOT NULL,
  `regio` int(10) unsigned NOT NULL,
  `telepules` int(10) unsigned NOT NULL,
  `varosresz` int(10) unsigned NOT NULL,
  `kategoria` int(10) unsigned NOT NULL,
  `jelleg` int(10) unsigned NOT NULL,
  `szobak` float(10,1) unsigned NOT NULL default '1.0',
  `alapterulet` int(10) unsigned NOT NULL,
  `ar` int(10) unsigned NOT NULL,
  `szintek` float(10,1) unsigned NOT NULL default '1.0',
  `garazs` int(10) unsigned NOT NULL,
  `megjegyzes` text collate utf8_unicode_ci NOT NULL,
  `cim` text collate utf8_unicode_ci NOT NULL,
  `statusz` int(10) unsigned NOT NULL default '0',
  `datum` int(10) unsigned NOT NULL,
  `ervenyes_datum` int(10) unsigned NOT NULL default '0',
  `email` tinytext collate utf8_unicode_ci NOT NULL,
  `jelszo` tinytext collate utf8_unicode_ci NOT NULL,
  `nev` tinytext collate utf8_unicode_ci NOT NULL,
  `telefon` tinytext collate utf8_unicode_ci NOT NULL,
  `kiemelt_datum` int(10) unsigned NOT NULL default '0',
  `uzletkoto` tinytext collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`hiid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

-- 
-- Tábla adatok: `hirdetesek`
-- 

INSERT INTO `hirdetesek` (`hiid`, `hirdetes_cime`, `regio`, `telepules`, `varosresz`, `kategoria`, `jelleg`, `szobak`, `alapterulet`, `ar`, `szintek`, `garazs`, `megjegyzes`, `cim`, `statusz`, `datum`, `ervenyes_datum`, `email`, `jelszo`, `nev`, `telefon`, `kiemelt_datum`, `uzletkoto`) VALUES 
(10, 'BÃ©relhetÅ‘ PanellakÃ¡s, 3 szoba', 1, 14, 0, 2, 2, 3.0, 76, 50000, 1.0, 1, 'Van egy nagy Ã¶reg redvÃ¡s Ã¡gy!', 'SzivÃ¡rvÃ¡ny u. 2', 3, 1239363552, 1262386799, 'peti@vagyok.hu', 'alma', 'ForgÃ¡cs PÃ©ter', '06207774444', 1262386799, 'BÃ¡rgyÃº BÃ©la'),
(8, 'Ãšj CsalÃ¡di hÃ¡z / Villa', 1, 181, 0, 0, 0, 0.0, 120, 20000000, 3.0, 0, '- medence\r\n- visegrÃ¡di vÃ¡rra nÃ©zÅ‘ kilÃ¡tÃ¡s\r\n- belsÅ‘ lift\r\n- bÃºtorozott\r\n- ingyen szemÃ©lyzet\r\n- Ã¡rvÃ­ztÅ±rÅ‘ tÃ¼kÃ¶rfÃºrÃ³gÃ©p', 'Kossuth u. 1.', 3, 1239305461, 1262386799, 'valaki@mas.hu', 'barack', 'Jon Doe', '01234567890', 1262386799, 'alma barack'),
(9, 'BÃ©relhetÅ‘ ÃœzlethelyisÃ©g, 1 szoba', 0, 0, 0, 6, 2, 1.0, 30, 500000, 1.0, 1, 'Az ï¿½zlethï¿½z mï¿½sodik emeletï¿½n talï¿½lhatï¿½ a helysï¿½g.\r\nTavasszal volt felï¿½jï¿½tva.', 'Zsï¿½kavï¿½r utca 20.', 1, 1239306425, 1262386799, 'valaki@mas.hu', 'alma', 'Mr. Smith', '00996660000', 1262386799, ''),
(7, 'BÃ©relhetÅ‘ PanellakÃ¡s, 4 szoba', 0, 0, 0, 2, 2, 100.0, 52, 90000, 4.0, 2, 'BÃºtorozott, 2 Ã©ve felÃºjÃ­tott fÃ¼rdÅ‘szobÃ¡val, Ã©s kilÃ¡tÃ¡ssal a parlamentre Ã©s a vÃ¡rra.\r\n1 percre a batthyÃ¡ny tÃ©rtÅ‘l.\r\n(Metro (M2), 86-os busz, 19-41-es villamos)', 'BatthiÃ¡ny u. 3.', 3, 1239305011, 1262386799, 'zsolt.kocsmarszky@yahoo.com', 'aezdV30v', 'Andrew Smith', '06905550000', 1262386799, 'alma barack'),
(1, 'HasznÃ¡lt TÃ©gla lakÃ¡s, 2 szoba', 0, 0, 3, 1, 1, 2.0, 54, 9000000, 0.0, 1, 'Hidd el, jÃ³l jÃ¡rok!', 'PetÅ‘fi SÃ¡ndor u. 48.', 3, 1237896541, 1262386799, 'kindlazoltan@gmail.com', 'barack', 'Kindla ZoltÃ¡n', '202580066', 1262386799, 'jÃ³ska'),
(2, 'HasznÃ¡lt CsalÃ¡di hÃ¡z / Villa, 5 szoba', 0, 0, 2, 0, 1, 5.0, 145, 48000000, 2.0, 0, 'MarhÃ¡ra nincs mÃ©g befejezve, de jÃ³ befektetÃ©s.', '', 3, 1237972953, 1241128799, 'sparheltkifozde@t-online.hu', 'alma', 'Helmeci Levente', '309311519', 1241128799, ''),
(3, 'BÃ©relhetÅ‘ Telek, 3 szoba', 1, 1, 0, 4, 2, 3.0, 236, 80000, 1.0, 0, '', '', 3, 1237982979, 1241128799, 'barna@vipmail.hu', 'epu3c8yv', 'TÃ³th BarnabÃ¡s', '703849932', 1241128799, 'alma barack'),
(4, 'HasznÃ¡lt CsalÃ¡di hÃ¡z / Villa, 5 szoba', 0, 0, 2, 0, 1, 5.5, 120, 65000000, 2.5, 0, 'kurva jÃ³', '', 3, 1238519122, 1241128799, 'sparheltkifozde@t-online.hu', 'levi', 'Levente', '456789', 1241128799, 'jÃ³ska'),
(5, 'Ãšj CsalÃ¡di hÃ¡z / Villa', 0, 0, 2, 0, 0, 0.0, 32, 233222, 0.0, 0, '', '', 3, 1238599890, 1241128799, 'zsa@sa.sa', '1233', 'Proba', '213124', 957131999, ''),
(6, 'Ãšj NyaralÃ³', 0, 0, 0, 4, 0, 0.0, 50, 10000000, 0.0, 1, 'JÃ³ fekvÃ©sÅ±, szÃ©p kilÃ¡tÃ¡ssal, boros pincÃ©vel meg egyebekkel\r\n\r\nbla bla', '', 3, 1239268646, 1241128799, 'valahol@valaki.hu', '1m9rnlzx', 'Teszt Lajos', '01234567', 957131999, 'BÃ¡rgyÃº BÃ©la'),
(11, 'HasznÃ¡lt NyaralÃ³, 1.5 szoba', 0, 0, 0, 4, 1, 1.5, 50, 140000, 1.0, 2, '', '', 2, 1240222742, 1262386799, 'peti@vagyok.hu', 'alma', 'ForgÃ¡cs PÃ©ter', '06207774444', 946767599, '');

-- --------------------------------------------------------

-- 
-- Tábla szerkezet: `stat`
-- 

CREATE TABLE `stat` (
  `hiid` int(10) unsigned NOT NULL,
  `szamlalo` int(10) unsigned NOT NULL default '1',
  `datum_ev` int(4) unsigned NOT NULL,
  `datum_honap` tinyint(2) unsigned NOT NULL,
  `datum_nap` tinyint(2) unsigned NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Tábla adatok: `stat`
-- 

INSERT INTO `stat` (`hiid`, `szamlalo`, `datum_ev`, `datum_honap`, `datum_nap`) VALUES 
(0, 2, 2009, 4, 15),
(8, 22, 2009, 4, 15),
(7, 1, 2009, 4, 15),
(0, 62, 2009, 4, 17),
(0, 237, 2009, 4, 18),
(10, 2, 2009, 4, 18),
(0, 305, 2009, 4, 19),
(8, 13, 2009, 4, 19),
(10, 11, 2009, 4, 19),
(7, 8, 2009, 4, 19),
(3, 1, 2009, 4, 19),
(6, 1, 2009, 4, 19),
(4, 1, 2009, 4, 19),
(1, 1, 2009, 4, 19),
(5, 1, 2009, 4, 19),
(0, 384, 2009, 4, 20),
(10, 9, 2009, 3, 26),
(10, 177, 2009, 3, 25),
(10, 212, 2009, 3, 24),
(10, 107, 2009, 3, 23),
(10, 7, 2009, 3, 22),
(10, 204, 2009, 3, 21),
(10, 41, 2009, 3, 20),
(10, 35, 2009, 3, 19),
(10, 158, 2009, 3, 18),
(10, 109, 2009, 3, 17),
(10, 214, 2009, 3, 16),
(10, 156, 2009, 3, 15),
(10, 73, 2009, 3, 14),
(10, 0, 2009, 3, 13),
(10, 209, 2009, 3, 12),
(10, 174, 2009, 3, 11),
(10, 114, 2009, 3, 10),
(10, 143, 2009, 3, 9),
(10, 211, 2009, 3, 8),
(10, 29, 2009, 3, 7),
(10, 112, 2009, 3, 6),
(10, 150, 2009, 3, 5),
(10, 40, 2009, 3, 4),
(10, 127, 2009, 3, 1),
(3, 1, 2009, 4, 20),
(10, 37, 2009, 4, 20),
(2, 1, 2009, 4, 20),
(8, 2, 2009, 4, 20),
(1, 1, 2009, 4, 20),
(4, 2, 2009, 4, 20),
(11, 1, 2009, 4, 20),
(0, 1, 2009, 4, 21),
(0, 95, 2009, 4, 22),
(10, 1, 2009, 4, 22),
(4, 1, 2009, 4, 22),
(8, 2, 2009, 4, 22),
(2, 1, 2009, 4, 22),
(1, 4, 2009, 4, 22),
(0, 129, 2009, 4, 23),
(11, 3, 2009, 4, 23),
(10, 6, 2009, 4, 23),
(7, 6, 2009, 4, 23),
(8, 2, 2009, 4, 23),
(2, 4, 2009, 4, 23),
(4, 1, 2009, 4, 23),
(1, 1, 2009, 4, 23),
(0, 2, 2009, 4, 30),
(10, 1, 2009, 4, 30);
