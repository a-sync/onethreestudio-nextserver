-- phpMyAdmin SQL Dump
-- version 2.7.0-pl1
-- http://www.phpmyadmin.net
-- 
-- Hoszt: localhost
-- Létrehozás ideje: 2008. Nov 30. 12:29
-- Szerver verzió: 5.0.32
-- PHP Verzió: 4.3.10-22
-- 
-- Adatbázis: `pertlevetke`
-- 

-- --------------------------------------------------------

-- 
-- Tábla szerkezet: `galeria`
-- 

CREATE TABLE `galeria` (
  `cat_id` int(10) unsigned NOT NULL auto_increment,
  `parent_id` int(10) unsigned NOT NULL,
  `name` tinytext collate utf8_hungarian_ci NOT NULL,
  PRIMARY KEY  (`cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

-- 
-- Tábla szerkezet: `hirek`
-- 

CREATE TABLE `hirek` (
  `hir_id` int(10) unsigned NOT NULL auto_increment,
  `title` tinytext collate utf8_hungarian_ci NOT NULL,
  `text` mediumtext collate utf8_hungarian_ci NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `priority` smallint(5) unsigned NOT NULL,
  `time` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`hir_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

-- 
-- Tábla szerkezet: `kepek`
-- 

CREATE TABLE `kepek` (
  `pic_id` int(10) unsigned NOT NULL auto_increment,
  `cat_id` int(10) unsigned NOT NULL,
  `title` tinytext collate utf8_hungarian_ci NOT NULL,
  `desc` text collate utf8_hungarian_ci NOT NULL,
  `tags` text collate utf8_hungarian_ci NOT NULL,
  `file` text collate utf8_hungarian_ci NOT NULL,
  PRIMARY KEY  (`pic_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------