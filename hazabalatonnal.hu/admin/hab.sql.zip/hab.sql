-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Hoszt: localhost
-- Létrehozás ideje: 2010. Nov 19. 20:23
-- Szerver verzió: 5.0.51
-- PHP Verzió: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Adatbázis: `hab`
-- 

-- --------------------------------------------------------

-- 
-- Tábla szerkezet: `hirdetesek`
-- 

CREATE TABLE `hirdetesek` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `cim` tinytext NOT NULL,
  `regio` tinyint(3) unsigned NOT NULL,
  `telepules` tinytext NOT NULL,
  `kategoria` tinyint(3) unsigned NOT NULL,
  `szoba` tinyint(3) unsigned NOT NULL,
  `alapterulet` int(10) unsigned NOT NULL,
  `ar` int(10) unsigned NOT NULL,
  `leiras` text NOT NULL,
  `ido` int(10) unsigned NOT NULL,
  `status` tinyint(3) unsigned NOT NULL default '0',
  `jegyzet` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- Tábla adatok: `hirdetesek`
-- 

INSERT INTO `hirdetesek` VALUES (1, 'Parti nyaraló', 18, 'Csopak', 1, 2, 40, 8000000, 'Tóra néző kilátással.', 1290121200, 1, '');
